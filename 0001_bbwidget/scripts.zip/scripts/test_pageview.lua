require "base"

local func_next_CPageView_test_scene = nil
local func_back_CPageView_test_scene = nil
local func_ref_CPageView_test_scene = nil

-- createCPageViewBasicTest
-- =====================================================
-- =====================================================
-- =====================================================
local function createCPageViewBasicTest()
	local baseScene = createScene()
	--next
	baseScene.btnNext:setOnClickScriptHandler(function(sender)
		func_next_CPageView_test_scene()
	end)
	--back
	baseScene.btnBack:setOnClickScriptHandler(function(sender)
		func_back_CPageView_test_scene()
	end)
	--ref
	baseScene.btnRef:setOnClickScriptHandler(function(sender)
		func_ref_CPageView_test_scene()
	end)
	
	baseScene.setTitle("BBPageViewBasicTest")
	baseScene.setDescription("PageView basic test")
	
	local function data_source(p_convertview, idx)
		local pPageCell = tolua.cast(p_convertview, "BBPageViewCell")
		local pButton = nil

		if pPageCell == nil then
			pPageCell = BBPageViewCell:new()
			pPageCell:autorelease()
			pPageCell:setBackgroundImage("background.png")

			pButton = BBButton:createWith9Sprite(CCSize(150, 50), "sprite9_btn1.png", "sprite9_btn2.png")
			pButton:getLabel():setFontSize(30.0)
			pButton:setPosition(CCPoint(484 / 2, 320 / 2))
			pButton:setTag(1)
			pPageCell:addChild(pButton)
		else
			pButton = tolua.cast(pPageCell:getChildByTag(1), "BBButton")
		end
		
		pButton:getLabel():setString(tostring(idx))

		return pPageCell;
	end
	
	local m_label = BBLabel:create()
	m_label:setAnchorPoint(CCPoint(0, 0.5))
	m_label:setPosition(CCPoint(800, 320))
	m_label:setFontSize(35.0)
	m_label:setString("none")
	baseScene.p_window:addChild(m_label)
	
	local function on_page_changed(sender, idx)
		m_label:setString(tostring(idx))
	end
	

	local pPageView = BBPageView:create(CCSize(484, 320))
	pPageView:setCountOfCell(10)
	pPageView:setDataSourceAdapterScriptHandler(data_source)
	pPageView:setOnPageChangedScriptHandler(on_page_changed)
	pPageView:setPosition(CCPoint(480, 320))
	baseScene.p_window:addChild(pPageView)
	pPageView:reloadData()
	
	return baseScene.p_scene;
end


-- createCPageViewVerticalTest
-- =====================================================
-- =====================================================
-- =====================================================
local function createCPageViewVerticalTest()
	local baseScene = createScene()
	--next
	baseScene.btnNext:setOnClickScriptHandler(function(sender)
		func_next_CPageView_test_scene()
	end)
	--back
	baseScene.btnBack:setOnClickScriptHandler(function(sender)
		func_back_CPageView_test_scene()
	end)
	--ref
	baseScene.btnRef:setOnClickScriptHandler(function(sender)
		func_ref_CPageView_test_scene()
	end)
	
	baseScene.setTitle("BBPageViewVerticalTest")
	baseScene.setDescription("PageView in vertical")
	
	
	local m_label = BBLabel:create()
	m_label:setAnchorPoint(CCPoint(0, 0.5))
	m_label:setPosition(CCPoint(800, 320))
	m_label:setFontSize(35.0)
	m_label:setString("none")
	baseScene.p_window:addChild(m_label)
	
	local function data_source(p_convertview, idx)
		local pPageCell = tolua.cast(p_convertview, "BBPageViewCell")
		local pButton = nil

		if pPageCell == nil then
			pPageCell = BBPageViewCell:new()
			pPageCell:autorelease()
			pPageCell:setBackgroundImage("background.png")

			pButton = BBButton:createWith9Sprite(CCSize(150, 50), "sprite9_btn1.png", "sprite9_btn2.png")
			pButton:getLabel():setFontSize(30.0)
			pButton:setPosition(CCPoint(484 / 2, 320 / 2))
			pButton:setTag(1)
			pPageCell:addChild(pButton)
		else
			pButton = tolua.cast(pPageCell:getChildByTag(1), "BBButton")
		end
		
		pButton:getLabel():setString(tostring(idx))

		return pPageCell;
	end
	
	local function on_page_changed(sender, idx)
		m_label:setString(tostring(idx))
	end
	
	local pPageView = BBPageView:create(CCSize(484, 320))
	pPageView:setCountOfCell(10)
	pPageView:setDataSourceAdapterScriptHandler(data_source)
	pPageView:setOnPageChangedScriptHandler(on_page_changed)
	pPageView:setPosition(CCPoint(480, 320))
	pPageView:setDirection(eScrollViewDirectionVertical)
	baseScene.p_window:addChild(pPageView)
	pPageView:reloadData()

	return baseScene.p_scene;
end





local _n_CPageView_test_idx = 0;

local function get_CPageView_test_scene()
	if _n_CPageView_test_idx == 0 then
		return createCPageViewBasicTest()
	elseif _n_CPageView_test_idx == 1 then
		return createCPageViewVerticalTest()
	else
		_n_CPageView_test_idx = 0;
		return createCPageViewBasicTest()
	end
	return nil
end

function push_CPageView_test_scene()
	_n_CPageView_test_idx = 0;
	local p_scene = get_CPageView_test_scene()
	_p_director:pushScene(p_scene)
end

func_next_CPageView_test_scene = function()
	_n_CPageView_test_idx = _n_CPageView_test_idx + 1;
	local p_scene = get_CPageView_test_scene()
	_p_director:replaceScene(p_scene)
end

func_back_CPageView_test_scene = function()
	_n_CPageView_test_idx = _n_CPageView_test_idx - 1;
	local p_scene = get_CPageView_test_scene()
	_p_director:replaceScene(p_scene)
end

func_ref_CPageView_test_scene = function()
	local p_scene = get_CPageView_test_scene()
	_p_director:replaceScene(p_scene)
end




























